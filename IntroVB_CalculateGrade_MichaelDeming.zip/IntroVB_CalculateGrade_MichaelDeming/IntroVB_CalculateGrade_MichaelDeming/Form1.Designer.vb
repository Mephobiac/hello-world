﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.e1TextBox = New System.Windows.Forms.TextBox()
        Me.e2TextBox = New System.Windows.Forms.TextBox()
        Me.e3TextBox = New System.Windows.Forms.TextBox()
        Me.e4TextBox = New System.Windows.Forms.TextBox()
        Me.e5TextBox = New System.Windows.Forms.TextBox()
        Me.e6TextBox = New System.Windows.Forms.TextBox()
        Me.q1TextBox = New System.Windows.Forms.TextBox()
        Me.q2TextBox = New System.Windows.Forms.TextBox()
        Me.q3TextBox = New System.Windows.Forms.TextBox()
        Me.q4TextBox = New System.Windows.Forms.TextBox()
        Me.q5TextBox = New System.Windows.Forms.TextBox()
        Me.q6TextBox = New System.Windows.Forms.TextBox()
        Me.p2TextBox = New System.Windows.Forms.TextBox()
        Me.p3TextBox = New System.Windows.Forms.TextBox()
        Me.p4TextBox = New System.Windows.Forms.TextBox()
        Me.p5TextBox = New System.Windows.Forms.TextBox()
        Me.p6TextBox = New System.Windows.Forms.TextBox()
        Me.mtpTextBox = New System.Windows.Forms.TextBox()
        Me.mteTextBox = New System.Windows.Forms.TextBox()
        Me.bTextBox = New System.Windows.Forms.TextBox()
        Me.feTextBox = New System.Windows.Forms.TextBox()
        Me.outputLabel = New System.Windows.Forms.Label()
        Me.calcGradeButton = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Exercises: Enter 0-40"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 198)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Quizzes: Enter 0-20"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(174, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(108, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Projects: Enter 0-60"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(174, 198)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(99, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Exams: Enter 0-50"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(174, 314)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(105, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Bonus: Enter 0 or 1"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 15)
        Me.Label6.TabIndex = 5
        '
        'e1TextBox
        '
        Me.e1TextBox.Location = New System.Drawing.Point(12, 27)
        Me.e1TextBox.Name = "e1TextBox"
        Me.e1TextBox.Size = New System.Drawing.Size(100, 23)
        Me.e1TextBox.TabIndex = 6
        Me.e1TextBox.Text = "Exercise 1"
        '
        'e2TextBox
        '
        Me.e2TextBox.Location = New System.Drawing.Point(12, 56)
        Me.e2TextBox.Name = "e2TextBox"
        Me.e2TextBox.Size = New System.Drawing.Size(100, 23)
        Me.e2TextBox.TabIndex = 7
        Me.e2TextBox.Text = "Exercise 2"
        '
        'e3TextBox
        '
        Me.e3TextBox.Location = New System.Drawing.Point(12, 85)
        Me.e3TextBox.Name = "e3TextBox"
        Me.e3TextBox.Size = New System.Drawing.Size(100, 23)
        Me.e3TextBox.TabIndex = 8
        Me.e3TextBox.Text = "Exercise 3"
        '
        'e4TextBox
        '
        Me.e4TextBox.Location = New System.Drawing.Point(12, 114)
        Me.e4TextBox.Name = "e4TextBox"
        Me.e4TextBox.Size = New System.Drawing.Size(100, 23)
        Me.e4TextBox.TabIndex = 9
        Me.e4TextBox.Text = "Exercise 4"
        '
        'e5TextBox
        '
        Me.e5TextBox.Location = New System.Drawing.Point(12, 143)
        Me.e5TextBox.Name = "e5TextBox"
        Me.e5TextBox.Size = New System.Drawing.Size(100, 23)
        Me.e5TextBox.TabIndex = 10
        Me.e5TextBox.Text = "Exercise 5"
        '
        'e6TextBox
        '
        Me.e6TextBox.Location = New System.Drawing.Point(12, 172)
        Me.e6TextBox.Name = "e6TextBox"
        Me.e6TextBox.Size = New System.Drawing.Size(100, 23)
        Me.e6TextBox.TabIndex = 11
        Me.e6TextBox.Text = "Exercise 6"
        '
        'q1TextBox
        '
        Me.q1TextBox.Location = New System.Drawing.Point(12, 216)
        Me.q1TextBox.Name = "q1TextBox"
        Me.q1TextBox.Size = New System.Drawing.Size(100, 23)
        Me.q1TextBox.TabIndex = 12
        Me.q1TextBox.Text = "Quiz 1"
        '
        'q2TextBox
        '
        Me.q2TextBox.Location = New System.Drawing.Point(12, 245)
        Me.q2TextBox.Name = "q2TextBox"
        Me.q2TextBox.Size = New System.Drawing.Size(100, 23)
        Me.q2TextBox.TabIndex = 13
        Me.q2TextBox.Text = "Quiz 2"
        '
        'q3TextBox
        '
        Me.q3TextBox.Location = New System.Drawing.Point(12, 274)
        Me.q3TextBox.Name = "q3TextBox"
        Me.q3TextBox.Size = New System.Drawing.Size(100, 23)
        Me.q3TextBox.TabIndex = 14
        Me.q3TextBox.Text = "Quiz 3"
        '
        'q4TextBox
        '
        Me.q4TextBox.Location = New System.Drawing.Point(12, 303)
        Me.q4TextBox.Name = "q4TextBox"
        Me.q4TextBox.Size = New System.Drawing.Size(100, 23)
        Me.q4TextBox.TabIndex = 15
        Me.q4TextBox.Text = "Quiz 4"
        '
        'q5TextBox
        '
        Me.q5TextBox.Location = New System.Drawing.Point(12, 332)
        Me.q5TextBox.Name = "q5TextBox"
        Me.q5TextBox.Size = New System.Drawing.Size(100, 23)
        Me.q5TextBox.TabIndex = 16
        Me.q5TextBox.Text = "Quiz 5"
        '
        'q6TextBox
        '
        Me.q6TextBox.Location = New System.Drawing.Point(12, 361)
        Me.q6TextBox.Name = "q6TextBox"
        Me.q6TextBox.Size = New System.Drawing.Size(100, 23)
        Me.q6TextBox.TabIndex = 17
        Me.q6TextBox.Text = "Quiz 6"
        '
        'p2TextBox
        '
        Me.p2TextBox.Location = New System.Drawing.Point(177, 27)
        Me.p2TextBox.Name = "p2TextBox"
        Me.p2TextBox.Size = New System.Drawing.Size(100, 23)
        Me.p2TextBox.TabIndex = 18
        Me.p2TextBox.Text = "Project 2"
        '
        'p3TextBox
        '
        Me.p3TextBox.Location = New System.Drawing.Point(177, 56)
        Me.p3TextBox.Name = "p3TextBox"
        Me.p3TextBox.Size = New System.Drawing.Size(100, 23)
        Me.p3TextBox.TabIndex = 19
        Me.p3TextBox.Text = "Project 3"
        '
        'p4TextBox
        '
        Me.p4TextBox.Location = New System.Drawing.Point(177, 85)
        Me.p4TextBox.Name = "p4TextBox"
        Me.p4TextBox.Size = New System.Drawing.Size(100, 23)
        Me.p4TextBox.TabIndex = 20
        Me.p4TextBox.Text = "Project 4"
        '
        'p5TextBox
        '
        Me.p5TextBox.Location = New System.Drawing.Point(177, 114)
        Me.p5TextBox.Name = "p5TextBox"
        Me.p5TextBox.Size = New System.Drawing.Size(100, 23)
        Me.p5TextBox.TabIndex = 21
        Me.p5TextBox.Text = "Project 5"
        '
        'p6TextBox
        '
        Me.p6TextBox.Location = New System.Drawing.Point(177, 143)
        Me.p6TextBox.Name = "p6TextBox"
        Me.p6TextBox.Size = New System.Drawing.Size(100, 23)
        Me.p6TextBox.TabIndex = 22
        Me.p6TextBox.Text = "Project 6"
        '
        'mtpTextBox
        '
        Me.mtpTextBox.Location = New System.Drawing.Point(177, 245)
        Me.mtpTextBox.Name = "mtpTextBox"
        Me.mtpTextBox.Size = New System.Drawing.Size(100, 23)
        Me.mtpTextBox.TabIndex = 23
        Me.mtpTextBox.Text = "Mid Term Project"
        '
        'mteTextBox
        '
        Me.mteTextBox.Location = New System.Drawing.Point(177, 216)
        Me.mteTextBox.Name = "mteTextBox"
        Me.mteTextBox.Size = New System.Drawing.Size(100, 23)
        Me.mteTextBox.TabIndex = 24
        Me.mteTextBox.Text = "Mid Term Exam"
        '
        'bTextBox
        '
        Me.bTextBox.Location = New System.Drawing.Point(177, 332)
        Me.bTextBox.Name = "bTextBox"
        Me.bTextBox.Size = New System.Drawing.Size(120, 23)
        Me.bTextBox.TabIndex = 25
        Me.bTextBox.Text = "Active Shooter Video"
        '
        'feTextBox
        '
        Me.feTextBox.Location = New System.Drawing.Point(177, 274)
        Me.feTextBox.Name = "feTextBox"
        Me.feTextBox.Size = New System.Drawing.Size(100, 23)
        Me.feTextBox.TabIndex = 26
        Me.feTextBox.Text = "Final Exam"
        '
        'outputLabel
        '
        Me.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.outputLabel.ForeColor = System.Drawing.Color.Blue
        Me.outputLabel.Location = New System.Drawing.Point(12, 398)
        Me.outputLabel.Name = "outputLabel"
        Me.outputLabel.Size = New System.Drawing.Size(285, 26)
        Me.outputLabel.TabIndex = 27
        '
        'calcGradeButton
        '
        Me.calcGradeButton.Location = New System.Drawing.Point(177, 361)
        Me.calcGradeButton.Name = "calcGradeButton"
        Me.calcGradeButton.Size = New System.Drawing.Size(120, 23)
        Me.calcGradeButton.TabIndex = 28
        Me.calcGradeButton.Text = "Calculate Grade"
        Me.calcGradeButton.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(12, 442)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(288, 15)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "*All boxes MUST be filled in, or the program will crash."
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(331, 466)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.calcGradeButton)
        Me.Controls.Add(Me.outputLabel)
        Me.Controls.Add(Me.feTextBox)
        Me.Controls.Add(Me.bTextBox)
        Me.Controls.Add(Me.mteTextBox)
        Me.Controls.Add(Me.mtpTextBox)
        Me.Controls.Add(Me.p6TextBox)
        Me.Controls.Add(Me.p5TextBox)
        Me.Controls.Add(Me.p4TextBox)
        Me.Controls.Add(Me.p3TextBox)
        Me.Controls.Add(Me.p2TextBox)
        Me.Controls.Add(Me.q6TextBox)
        Me.Controls.Add(Me.q5TextBox)
        Me.Controls.Add(Me.q4TextBox)
        Me.Controls.Add(Me.q3TextBox)
        Me.Controls.Add(Me.q2TextBox)
        Me.Controls.Add(Me.q1TextBox)
        Me.Controls.Add(Me.e6TextBox)
        Me.Controls.Add(Me.e5TextBox)
        Me.Controls.Add(Me.e4TextBox)
        Me.Controls.Add(Me.e3TextBox)
        Me.Controls.Add(Me.e2TextBox)
        Me.Controls.Add(Me.e1TextBox)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Current Grade Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents e1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents e2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents e3TextBox As System.Windows.Forms.TextBox
    Friend WithEvents e4TextBox As System.Windows.Forms.TextBox
    Friend WithEvents e5TextBox As System.Windows.Forms.TextBox
    Friend WithEvents e6TextBox As System.Windows.Forms.TextBox
    Friend WithEvents q1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents q2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents q3TextBox As System.Windows.Forms.TextBox
    Friend WithEvents q4TextBox As System.Windows.Forms.TextBox
    Friend WithEvents q5TextBox As System.Windows.Forms.TextBox
    Friend WithEvents q6TextBox As System.Windows.Forms.TextBox
    Friend WithEvents p2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents p3TextBox As System.Windows.Forms.TextBox
    Friend WithEvents p4TextBox As System.Windows.Forms.TextBox
    Friend WithEvents p5TextBox As System.Windows.Forms.TextBox
    Friend WithEvents p6TextBox As System.Windows.Forms.TextBox
    Friend WithEvents mtpTextBox As System.Windows.Forms.TextBox
    Friend WithEvents mteTextBox As System.Windows.Forms.TextBox
    Friend WithEvents bTextBox As System.Windows.Forms.TextBox
    Friend WithEvents feTextBox As System.Windows.Forms.TextBox
    Friend WithEvents outputLabel As System.Windows.Forms.Label
    Friend WithEvents calcGradeButton As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label

End Class
