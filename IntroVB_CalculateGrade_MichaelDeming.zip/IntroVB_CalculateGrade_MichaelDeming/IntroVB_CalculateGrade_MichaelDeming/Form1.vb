﻿Public Class Form1
    ' the following variables hold the user input grades for each text box
    Dim e1Grade As Integer
    Dim e2Grade As Integer
    Dim e3Grade As Integer
    Dim e4Grade As Integer
    Dim e5Grade As Integer
    Dim e6Grade As Integer
    Dim q1Grade As Integer
    Dim q2Grade As Integer
    Dim q3Grade As Integer
    Dim q4Grade As Integer
    Dim q5Grade As Integer
    Dim q6Grade As Integer
    Dim p2Grade As Integer
    Dim p3Grade As Integer
    Dim p4Grade As Integer
    Dim p5Grade As Integer
    Dim p6Grade As Integer
    Dim mteGrade As Integer
    Dim mtpGrade As Integer
    Dim feGrade As Integer
    Dim bGrade As Integer
    Dim totalGrade As Double = 811 ' variable set to 811 as it is the maximum points you can earn
    Dim userGrade As Double ' variable to hold the sum of the user's grades
    Dim letterGrade As Double ' variable to hold the calculated letter and percent grade

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub calcGradeButton_Click(sender As Object, e As EventArgs) Handles calcGradeButton.Click
        ' the following lines assign each variable the user input from their respective text boxes
        e1Grade = e1TextBox.Text
        e2Grade = e2TextBox.Text
        e3Grade = e3TextBox.Text
        e4Grade = e4TextBox.Text
        e5Grade = e5TextBox.Text
        e6Grade = e6TextBox.Text
        q1Grade = q1TextBox.Text
        q2Grade = q2TextBox.Text
        q3Grade = q3TextBox.Text
        q4Grade = q4TextBox.Text
        q5Grade = q5TextBox.Text
        q6Grade = q6TextBox.Text
        p2Grade = p2TextBox.Text
        p3Grade = p3TextBox.Text
        p4Grade = p4TextBox.Text
        p5Grade = p5TextBox.Text
        p6Grade = p6TextBox.Text
        mteGrade = mteTextBox.Text
        mtpGrade = mtpTextBox.Text
        feGrade = feTextBox.Text
        bGrade = bTextBox.Text
        ' userGrade is set to the sum of all the entered grades
        userGrade = e1Grade + e2Grade + e3Grade + e4Grade + e5Grade + e6Grade + q1Grade + q2Grade + q3Grade + q4Grade + q5Grade + q6Grade + p2Grade + p3Grade + p4Grade + p5Grade + p6Grade + mteGrade + mtpGrade + feGrade + bGrade
        letterGrade = userGrade / totalGrade ' divides the total sum of the grades by the maximum grade to determine the percent value
        Select Case userGrade ' determines which letter grade was earned
            Case 771 To 811 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or an A" ' displays the message with the grade as a percent and the respective letter
            Case 755 To 770 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or an A-" ' displays the message with the grade as a percent and the respective letter
            Case 739 To 754 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or a B+" ' displays the message with the grade as a percent and the respective letter
            Case 706 To 738 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or a B" ' displays the message with the grade as a percent and the respective letter
            Case 690 To 705 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or a B-" ' displays the message with the grade as a percent and the respective letter
            Case 674 To 689 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or a C+" ' displays the message with the grade as a percent and the respective letter
            Case 641 To 673 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or a C" ' displays the message with the grade as a percent and the respective letter
            Case 625 To 640 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or a C-" ' displays the message with the grade as a percent and the respective letter
            Case 609 To 624 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or a D+" ' displays the message with the grade as a percent and the respective letter
            Case 568 To 608 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or a D" ' displays the message with the grade as a percent and the respective letter
            Case 0 To 567 ' if the users grade was in this...
                outputLabel.Text = "Your current grade this semester is " & FormatPercent(letterGrade) & " or an F" ' displays the message with the grade as a percent and the respective letter
        End Select


    End Sub
    ' the following lines of code clear any text box when it is clicked on for fast grade entering capabilities...
    Private Sub e1TextBox_Click(sender As Object, e As EventArgs) Handles e1TextBox.Click
        e1TextBox.Clear()
    End Sub
    Private Sub e2TextBox_Click(sender As Object, e As EventArgs) Handles e2TextBox.Click
        e2TextBox.Clear()
    End Sub
    Private Sub e3TextBox_Click(sender As Object, e As EventArgs) Handles e3TextBox.Click
        e3TextBox.Clear()
    End Sub
    Private Sub e4TextBox_Click(sender As Object, e As EventArgs) Handles e4TextBox.Click
        e4TextBox.Clear()
    End Sub
    Private Sub e5TextBox_Click(sender As Object, e As EventArgs) Handles e5TextBox.Click
        e5TextBox.Clear()
    End Sub
    Private Sub e6TextBox_Click(sender As Object, e As EventArgs) Handles e6TextBox.Click
        e6TextBox.Clear()
    End Sub
    Private Sub q1TextBox_Click(sender As Object, e As EventArgs) Handles q1TextBox.Click
        q1TextBox.Clear()
    End Sub
    Private Sub q2TextBox_Click(sender As Object, e As EventArgs) Handles q2TextBox.Click
        q2TextBox.Clear()
    End Sub
    Private Sub q3TextBox_Click(sender As Object, e As EventArgs) Handles q3TextBox.Click
        q3TextBox.Clear()
    End Sub
    Private Sub q4TextBox_Click(sender As Object, e As EventArgs) Handles q4TextBox.Click
        q4TextBox.Clear()
    End Sub
    Private Sub q5TextBox_Click(sender As Object, e As EventArgs) Handles q5TextBox.Click
        q5TextBox.Clear()
    End Sub
    Private Sub q6TextBox_Click(sender As Object, e As EventArgs) Handles q6TextBox.Click
        q6TextBox.Clear()
    End Sub
    Private Sub p2TextBox_Click(sender As Object, e As EventArgs) Handles p2TextBox.Click
        p2TextBox.Clear()
    End Sub
    Private Sub p3TextBox_Click(sender As Object, e As EventArgs) Handles p3TextBox.Click
        p3TextBox.Clear()
    End Sub
    Private Sub p4TextBox_Click(sender As Object, e As EventArgs) Handles p4TextBox.Click
        p4TextBox.Clear()
    End Sub
    Private Sub p5TextBox_Click(sender As Object, e As EventArgs) Handles p5TextBox.Click
        p5TextBox.Clear()
    End Sub
    Private Sub p6TextBox_Click(sender As Object, e As EventArgs) Handles p6TextBox.Click
        p6TextBox.Clear()
    End Sub
    Private Sub mteTextBox_Click(sender As Object, e As EventArgs) Handles mteTextBox.Click
        mteTextBox.Clear()
    End Sub
    Private Sub mtpTextBox_Click(sender As Object, e As EventArgs) Handles mtpTextBox.Click
        mtpTextBox.Clear()
    End Sub
    Private Sub feTextBox_Click(sender As Object, e As EventArgs) Handles feTextBox.Click
        feTextBox.Clear()
    End Sub
    Private Sub bTextBox_Click(sender As Object, e As EventArgs) Handles bTextBox.Click
        bTextBox.Clear()
    End Sub

End Class
