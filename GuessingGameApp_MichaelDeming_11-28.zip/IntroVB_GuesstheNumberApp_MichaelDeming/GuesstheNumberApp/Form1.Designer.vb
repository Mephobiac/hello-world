﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.newGameButton = New System.Windows.Forms.Button()
        Me.enterButton = New System.Windows.Forms.Button()
        Me.dynamicLabel = New System.Windows.Forms.Label()
        Me.guessTextBox = New System.Windows.Forms.TextBox()
        Me.outputLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'newGameButton
        '
        Me.newGameButton.Location = New System.Drawing.Point(12, 12)
        Me.newGameButton.Name = "newGameButton"
        Me.newGameButton.Size = New System.Drawing.Size(87, 27)
        Me.newGameButton.TabIndex = 0
        Me.newGameButton.Text = "New Game"
        Me.newGameButton.UseVisualStyleBackColor = True
        '
        'enterButton
        '
        Me.enterButton.Location = New System.Drawing.Point(12, 55)
        Me.enterButton.Name = "enterButton"
        Me.enterButton.Size = New System.Drawing.Size(87, 27)
        Me.enterButton.TabIndex = 1
        Me.enterButton.Text = "Guess!"
        Me.enterButton.UseVisualStyleBackColor = True
        '
        'dynamicLabel
        '
        Me.dynamicLabel.Location = New System.Drawing.Point(101, 12)
        Me.dynamicLabel.Name = "dynamicLabel"
        Me.dynamicLabel.Size = New System.Drawing.Size(145, 27)
        Me.dynamicLabel.TabIndex = 2
        Me.dynamicLabel.Text = "-- Select new game --"
        Me.dynamicLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'guessTextBox
        '
        Me.guessTextBox.Location = New System.Drawing.Point(12, 99)
        Me.guessTextBox.Name = "guessTextBox"
        Me.guessTextBox.Size = New System.Drawing.Size(124, 23)
        Me.guessTextBox.TabIndex = 3
        '
        'outputLabel
        '
        Me.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.outputLabel.Location = New System.Drawing.Point(270, 12)
        Me.outputLabel.Name = "outputLabel"
        Me.outputLabel.Size = New System.Drawing.Size(140, 110)
        Me.outputLabel.TabIndex = 4
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(422, 134)
        Me.Controls.Add(Me.outputLabel)
        Me.Controls.Add(Me.guessTextBox)
        Me.Controls.Add(Me.dynamicLabel)
        Me.Controls.Add(Me.enterButton)
        Me.Controls.Add(Me.newGameButton)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Guess the Number 1-100"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents newGameButton As System.Windows.Forms.Button
    Friend WithEvents enterButton As System.Windows.Forms.Button
    Friend WithEvents dynamicLabel As System.Windows.Forms.Label
    Friend WithEvents guessTextBox As System.Windows.Forms.TextBox
    Friend WithEvents outputLabel As System.Windows.Forms.Label

End Class
