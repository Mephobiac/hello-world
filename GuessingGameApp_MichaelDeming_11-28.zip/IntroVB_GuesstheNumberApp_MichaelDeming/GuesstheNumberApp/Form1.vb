﻿Public Class Form1
    Dim randomObject As New Random() ' creates a random object
    Dim randomNumber As Integer ' creates a variable for the random number
    Dim userGuess As Integer ' creates a variable for the user's guess
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles newGameButton.Click
        randomNumber = randomObject.Next(1, 101) ' generates a random number between 1 and 100
        guessTextBox.Enabled = True ' enables the text box
        guessTextBox.Focus() ' gives the text box focus
        enterButton.Enabled = True ' enables the enter button
        dynamicLabel.Text = "-- Enter your guess --" ' displays the message in the dynamic label
        outputLabel.Text = "" ' clears the output label
        guessTextBox.Text = "" ' clears the text box
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        guessTextBox.Enabled = False ' disables the text box on load
    End Sub

    Private Sub enterButton_Click(sender As Object, e As EventArgs) Handles enterButton.Click
        guessTextBox.Focus() ' gives the text box focus
        If guessTextBox.Text = "" Then
            outputLabel.Text = "-- Guess not valid --" ' never actually displays because it gets overidden, but stops the app from crashing 
        Else
            userGuess = guessTextBox.Text ' gets the user's guess and stores it in the variable 
        End If

        If userGuess = randomNumber Then ' if the guess equals the random number
            outputLabel.Text = "Correct!" ' displays the message in the output label
            newGameButton.Focus() ' gives the new game button focus
            guessTextBox.Enabled = False ' disables the text box
            enterButton.Enabled = False ' disables the enter button
        ElseIf userGuess < randomNumber Then ' if the guess is less than the random number
            outputLabel.Text = "Too low..."  ' displays the message in the output label
        ElseIf userGuess > randomNumber Then ' if the guess is less than the random number
            outputLabel.Text = "Too high man..."  ' displays the message in the output label
        End If
    End Sub
End Class
