﻿Public Class GasPump
    Dim regular As Double = 2.69 ' stores the price of regular grade gas
    Dim special As Double = 2.79 ' stores the price of special grade gas
    Dim super As Double = 2.89 ' stores the price of super grade gas
    Dim numGallons As Double ' stores the number of gallons entered by the user
    Dim totalCost As Double ' stores the calculated total cost

    ' Method CalculateCost takes the gasGrade as a Double and Returns the totalCost as a Double
    Function CalculateCost(gasGrade As Double) As Double
        numGallons = gallonTextBox.Text ' gets numGallons entered by the user
        totalCost = numGallons * gasGrade ' multiplies numGallons by the chosen gasGrade to determine totalCost

        Return totalCost ' returns totalCost
    End Function

    Private Sub regularButton_Click(sender As Object, e As EventArgs) Handles regularButton.Click
        outputLabel.Text = "Total: " & String.Format("{0:C}", CalculateCost(regular)) ' calls the CalculateCost Method and passes it the gasGrade, then displays the totalCost in the output label in the currency format
    End Sub

    Private Sub specialButton_Click(sender As Object, e As EventArgs) Handles specialButton.Click
        outputLabel.Text = "Total: " & String.Format("{0:C}", CalculateCost(special)) ' calls the CalculateCost Method and passes it the gasGrade, then displays the totalCost in the output label in the currency format
    End Sub

    Private Sub superButton_Click(sender As Object, e As EventArgs) Handles superButton.Click
        outputLabel.Text = "Total: " & String.Format("{0:C}", CalculateCost(super)) ' calls the CalculateCost Method and passes it the gasGrade, then displays the totalCost in the output label in the currency format
    End Sub
End Class
