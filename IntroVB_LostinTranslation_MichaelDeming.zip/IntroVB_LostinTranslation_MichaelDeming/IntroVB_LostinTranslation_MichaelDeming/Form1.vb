﻿Public Class LostInTranslation
    'The following variables make it easier to copy and paste code without memorizing the words
    Dim engOne As String = "one"
    Dim engTwo As String = "two"
    Dim engThree As String = "three"
    Dim engFour As String = "four"
    Dim engFive As String = "five"
    Dim engSix As String = "six"
    Dim engSeven As String = "seven"
    Dim engEight As String = "eight"
    Dim engNine As String = "nine"
    Dim freOne As String = "un"
    Dim freTwo As String = "deux"
    Dim freThree As String = "trois"
    Dim freFour As String = "quatre"
    Dim freFive As String = "cinq"
    Dim freSix As String = "six"
    Dim freSeven As String = "sept"
    Dim freEight As String = "huit"
    Dim freNine As String = "neuf"
    Dim spaOne As String = "uno"
    Dim spaTwo As String = "dos"
    Dim spaThree As String = "tres"
    Dim spaFour As String = "cuatro"
    Dim spaFive As String = "cinco"
    Dim spaSix As String = "seis"
    Dim spaSeven As String = "siete"
    Dim spaEight As String = "ocho"
    Dim spaNine As String = "nueve"
    Dim gerOne As String = "eins"
    Dim gerTwo As String = "zwei"
    Dim gerThree As String = "drei"
    Dim gerFour As String = "vier"
    Dim gerFive As String = "funf"
    Dim gerSix As String = "sechs"
    Dim gerSeven As String = "sieben"
    Dim gerEight As String = "acht"
    Dim gerNine As String = "neun"
    Dim outputLanguage As Integer ' is used to determine which language to translate to


    Private Sub translateButton_Click(sender As Object, e As EventArgs) Handles translateButton.Click
        Dim userInput As String = inputTextBox.Text ' variable that holds the users input
        'For english to all
        If userInput = engOne Then ' determines what number was entered by the user
            Select Case outputLanguage ' determines what language to translate to, either 1, 2, 3, or 4 for english, french, spanish, and german respectively
                Case 1 : translationLabel.Text = engOne ' displays the translated number in the output label
                Case 2 : translationLabel.Text = freOne ' the rest of the code does the same things but for different user inputs
                Case 3 : translationLabel.Text = spaOne
                Case 4 : translationLabel.Text = gerOne
            End Select
        ElseIf userInput = engTwo Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engTwo
                Case 2 : translationLabel.Text = freTwo
                Case 3 : translationLabel.Text = spaTwo
                Case 4 : translationLabel.Text = gerTwo
            End Select
        ElseIf userInput = engThree Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engThree
                Case 2 : translationLabel.Text = freThree
                Case 3 : translationLabel.Text = spaThree
                Case 4 : translationLabel.Text = gerThree
            End Select
        ElseIf userInput = engFour Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engFour
                Case 2 : translationLabel.Text = freFour
                Case 3 : translationLabel.Text = spaFour
                Case 4 : translationLabel.Text = gerFour
            End Select
        ElseIf userInput = engFive Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engFive
                Case 2 : translationLabel.Text = freFive
                Case 3 : translationLabel.Text = spaFive
                Case 4 : translationLabel.Text = gerFive
            End Select
        ElseIf userInput = engSix Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engSix
                Case 2 : translationLabel.Text = freSix
                Case 3 : translationLabel.Text = spaSix
                Case 4 : translationLabel.Text = gerSix
            End Select
        ElseIf userInput = engSeven Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engSeven
                Case 2 : translationLabel.Text = freSeven
                Case 3 : translationLabel.Text = spaSeven
                Case 4 : translationLabel.Text = gerSeven
            End Select
        ElseIf userInput = engEight Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engEight
                Case 2 : translationLabel.Text = freEight
                Case 3 : translationLabel.Text = spaEight
                Case 4 : translationLabel.Text = gerEight
            End Select
        ElseIf userInput = engNine Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engNine
                Case 2 : translationLabel.Text = freNine
                Case 3 : translationLabel.Text = spaNine
                Case 4 : translationLabel.Text = gerNine
            End Select
        End If
        'For french to all
        If userInput = freOne Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engOne
                Case 2 : translationLabel.Text = freOne
                Case 3 : translationLabel.Text = spaOne
                Case 4 : translationLabel.Text = gerOne
            End Select
        ElseIf userInput = freTwo Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engTwo
                Case 2 : translationLabel.Text = freTwo
                Case 3 : translationLabel.Text = spaTwo
                Case 4 : translationLabel.Text = gerTwo
            End Select
        ElseIf userInput = freThree Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engThree
                Case 2 : translationLabel.Text = freThree
                Case 3 : translationLabel.Text = spaThree
                Case 4 : translationLabel.Text = gerThree
            End Select
        ElseIf userInput = freFour Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engFour
                Case 2 : translationLabel.Text = freFour
                Case 3 : translationLabel.Text = spaFour
                Case 4 : translationLabel.Text = gerFour
            End Select
        ElseIf userInput = freFive Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engFive
                Case 2 : translationLabel.Text = freFive
                Case 3 : translationLabel.Text = spaFive
                Case 4 : translationLabel.Text = gerFive
            End Select
        ElseIf userInput = freSix Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engSix
                Case 2 : translationLabel.Text = freSix
                Case 3 : translationLabel.Text = spaSix
                Case 4 : translationLabel.Text = gerSix
            End Select
        ElseIf userInput = freSeven Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engSeven
                Case 2 : translationLabel.Text = freSeven
                Case 3 : translationLabel.Text = spaSeven
                Case 4 : translationLabel.Text = gerSeven
            End Select
        ElseIf userInput = freEight Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engEight
                Case 2 : translationLabel.Text = freEight
                Case 3 : translationLabel.Text = spaEight
                Case 4 : translationLabel.Text = gerEight
            End Select
        ElseIf userInput = freNine Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engNine
                Case 2 : translationLabel.Text = freNine
                Case 3 : translationLabel.Text = spaNine
                Case 4 : translationLabel.Text = gerNine
            End Select
        End If
        'For spanish to all
        If userInput = spaOne Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engOne
                Case 2 : translationLabel.Text = freOne
                Case 3 : translationLabel.Text = spaOne
                Case 4 : translationLabel.Text = gerOne
            End Select
        ElseIf userInput = spaTwo Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engTwo
                Case 2 : translationLabel.Text = freTwo
                Case 3 : translationLabel.Text = spaTwo
                Case 4 : translationLabel.Text = gerTwo
            End Select
        ElseIf userInput = spaThree Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engThree
                Case 2 : translationLabel.Text = freThree
                Case 3 : translationLabel.Text = spaThree
                Case 4 : translationLabel.Text = gerThree
            End Select
        ElseIf userInput = spaFour Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engFour
                Case 2 : translationLabel.Text = freFour
                Case 3 : translationLabel.Text = spaFour
                Case 4 : translationLabel.Text = gerFour
            End Select
        ElseIf userInput = spaFive Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engFive
                Case 2 : translationLabel.Text = freFive
                Case 3 : translationLabel.Text = spaFive
                Case 4 : translationLabel.Text = gerFive
            End Select
        ElseIf userInput = spaSix Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engSix
                Case 2 : translationLabel.Text = freSix
                Case 3 : translationLabel.Text = spaSix
                Case 4 : translationLabel.Text = gerSix
            End Select
        ElseIf userInput = spaSeven Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engSeven
                Case 2 : translationLabel.Text = freSeven
                Case 3 : translationLabel.Text = spaSeven
                Case 4 : translationLabel.Text = gerSeven
            End Select
        ElseIf userInput = spaEight Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engEight
                Case 2 : translationLabel.Text = freEight
                Case 3 : translationLabel.Text = spaEight
                Case 4 : translationLabel.Text = gerEight
            End Select
        ElseIf userInput = spaNine Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engNine
                Case 2 : translationLabel.Text = freNine
                Case 3 : translationLabel.Text = spaNine
                Case 4 : translationLabel.Text = gerNine
            End Select
        End If
        'For german to all
        If userInput = gerOne Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engOne
                Case 2 : translationLabel.Text = freOne
                Case 3 : translationLabel.Text = spaOne
                Case 4 : translationLabel.Text = gerOne
            End Select
        ElseIf userInput = gerTwo Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engTwo
                Case 2 : translationLabel.Text = freTwo
                Case 3 : translationLabel.Text = spaTwo
                Case 4 : translationLabel.Text = gerTwo
            End Select
        ElseIf userInput = gerThree Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engThree
                Case 2 : translationLabel.Text = freThree
                Case 3 : translationLabel.Text = spaThree
                Case 4 : translationLabel.Text = gerThree
            End Select
        ElseIf userInput = gerFour Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engFour
                Case 2 : translationLabel.Text = freFour
                Case 3 : translationLabel.Text = spaFour
                Case 4 : translationLabel.Text = gerFour
            End Select
        ElseIf userInput = gerFive Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engFive
                Case 2 : translationLabel.Text = freFive
                Case 3 : translationLabel.Text = spaFive
                Case 4 : translationLabel.Text = gerFive
            End Select
        ElseIf userInput = gerSix Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engSix
                Case 2 : translationLabel.Text = freSix
                Case 3 : translationLabel.Text = spaSix
                Case 4 : translationLabel.Text = gerSix
            End Select
        ElseIf userInput = gerSeven Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engSeven
                Case 2 : translationLabel.Text = freSeven
                Case 3 : translationLabel.Text = spaSeven
                Case 4 : translationLabel.Text = gerSeven
            End Select
        ElseIf userInput = gerEight Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engEight
                Case 2 : translationLabel.Text = freEight
                Case 3 : translationLabel.Text = spaEight
                Case 4 : translationLabel.Text = gerEight
            End Select
        ElseIf userInput = gerNine Then
            Select Case outputLanguage
                Case 1 : translationLabel.Text = engNine
                Case 2 : translationLabel.Text = freNine
                Case 3 : translationLabel.Text = spaNine
                Case 4 : translationLabel.Text = gerNine
            End Select
        End If
    End Sub

    Private Sub outputEngRadButton_CheckedChanged(sender As Object, e As EventArgs) Handles outputEngRadButton.CheckedChanged
        outputLanguage = 1 ' if english is selected, stores the value 1 in the variable
    End Sub

    Private Sub outputFreRadButton_CheckedChanged(sender As Object, e As EventArgs) Handles outputFreRadButton.CheckedChanged
        outputLanguage = 2 ' if french is selected, stores the value 2 in the variable
    End Sub

    Private Sub outputSpaRadButton_CheckedChanged(sender As Object, e As EventArgs) Handles outputSpaRadButton.CheckedChanged
        outputLanguage = 3 ' if spanish is selected, stores the value 3 in the variable
    End Sub

    Private Sub outputGerRadButton_CheckedChanged(sender As Object, e As EventArgs) Handles outputGerRadButton.CheckedChanged
        outputLanguage = 4 ' if german is selected, stores the value 4 in the variable
    End Sub
End Class
