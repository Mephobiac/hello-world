﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LostInTranslation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.outputEngRadButton = New System.Windows.Forms.RadioButton()
        Me.outputFreRadButton = New System.Windows.Forms.RadioButton()
        Me.outputSpaRadButton = New System.Windows.Forms.RadioButton()
        Me.outputGerRadButton = New System.Windows.Forms.RadioButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.inputEngRadButton = New System.Windows.Forms.RadioButton()
        Me.inputFreRadButton = New System.Windows.Forms.RadioButton()
        Me.inputSpaRadButton = New System.Windows.Forms.RadioButton()
        Me.inputGerRadButton = New System.Windows.Forms.RadioButton()
        Me.inputLabel = New System.Windows.Forms.Label()
        Me.outputLabel = New System.Windows.Forms.Label()
        Me.inputTextBox = New System.Windows.Forms.TextBox()
        Me.translationLabel = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.translateButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.outputEngRadButton)
        Me.Panel1.Controls.Add(Me.outputFreRadButton)
        Me.Panel1.Controls.Add(Me.outputSpaRadButton)
        Me.Panel1.Controls.Add(Me.outputGerRadButton)
        Me.Panel1.Location = New System.Drawing.Point(205, 37)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(114, 100)
        Me.Panel1.TabIndex = 0
        '
        'outputEngRadButton
        '
        Me.outputEngRadButton.AutoSize = True
        Me.outputEngRadButton.Location = New System.Drawing.Point(3, 3)
        Me.outputEngRadButton.Name = "outputEngRadButton"
        Me.outputEngRadButton.Size = New System.Drawing.Size(63, 19)
        Me.outputEngRadButton.TabIndex = 1
        Me.outputEngRadButton.TabStop = True
        Me.outputEngRadButton.Text = "English"
        Me.outputEngRadButton.UseVisualStyleBackColor = True
        '
        'outputFreRadButton
        '
        Me.outputFreRadButton.AutoSize = True
        Me.outputFreRadButton.Location = New System.Drawing.Point(3, 28)
        Me.outputFreRadButton.Name = "outputFreRadButton"
        Me.outputFreRadButton.Size = New System.Drawing.Size(61, 19)
        Me.outputFreRadButton.TabIndex = 2
        Me.outputFreRadButton.TabStop = True
        Me.outputFreRadButton.Text = "French"
        Me.outputFreRadButton.UseVisualStyleBackColor = True
        '
        'outputSpaRadButton
        '
        Me.outputSpaRadButton.AutoSize = True
        Me.outputSpaRadButton.Location = New System.Drawing.Point(3, 53)
        Me.outputSpaRadButton.Name = "outputSpaRadButton"
        Me.outputSpaRadButton.Size = New System.Drawing.Size(66, 19)
        Me.outputSpaRadButton.TabIndex = 3
        Me.outputSpaRadButton.TabStop = True
        Me.outputSpaRadButton.Text = "Spanish"
        Me.outputSpaRadButton.UseVisualStyleBackColor = True
        '
        'outputGerRadButton
        '
        Me.outputGerRadButton.AutoSize = True
        Me.outputGerRadButton.Location = New System.Drawing.Point(3, 78)
        Me.outputGerRadButton.Name = "outputGerRadButton"
        Me.outputGerRadButton.Size = New System.Drawing.Size(67, 19)
        Me.outputGerRadButton.TabIndex = 4
        Me.outputGerRadButton.TabStop = True
        Me.outputGerRadButton.Text = "German"
        Me.outputGerRadButton.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.inputEngRadButton)
        Me.Panel2.Controls.Add(Me.inputFreRadButton)
        Me.Panel2.Controls.Add(Me.inputSpaRadButton)
        Me.Panel2.Controls.Add(Me.inputGerRadButton)
        Me.Panel2.Location = New System.Drawing.Point(12, 37)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(114, 100)
        Me.Panel2.TabIndex = 1
        '
        'inputEngRadButton
        '
        Me.inputEngRadButton.AutoSize = True
        Me.inputEngRadButton.Location = New System.Drawing.Point(3, 3)
        Me.inputEngRadButton.Name = "inputEngRadButton"
        Me.inputEngRadButton.Size = New System.Drawing.Size(63, 19)
        Me.inputEngRadButton.TabIndex = 1
        Me.inputEngRadButton.TabStop = True
        Me.inputEngRadButton.Text = "English"
        Me.inputEngRadButton.UseVisualStyleBackColor = True
        '
        'inputFreRadButton
        '
        Me.inputFreRadButton.AutoSize = True
        Me.inputFreRadButton.Location = New System.Drawing.Point(3, 28)
        Me.inputFreRadButton.Name = "inputFreRadButton"
        Me.inputFreRadButton.Size = New System.Drawing.Size(61, 19)
        Me.inputFreRadButton.TabIndex = 2
        Me.inputFreRadButton.TabStop = True
        Me.inputFreRadButton.Text = "French"
        Me.inputFreRadButton.UseVisualStyleBackColor = True
        '
        'inputSpaRadButton
        '
        Me.inputSpaRadButton.AutoSize = True
        Me.inputSpaRadButton.Location = New System.Drawing.Point(3, 53)
        Me.inputSpaRadButton.Name = "inputSpaRadButton"
        Me.inputSpaRadButton.Size = New System.Drawing.Size(66, 19)
        Me.inputSpaRadButton.TabIndex = 3
        Me.inputSpaRadButton.TabStop = True
        Me.inputSpaRadButton.Text = "Spanish"
        Me.inputSpaRadButton.UseVisualStyleBackColor = True
        '
        'inputGerRadButton
        '
        Me.inputGerRadButton.AutoSize = True
        Me.inputGerRadButton.Location = New System.Drawing.Point(3, 78)
        Me.inputGerRadButton.Name = "inputGerRadButton"
        Me.inputGerRadButton.Size = New System.Drawing.Size(67, 19)
        Me.inputGerRadButton.TabIndex = 4
        Me.inputGerRadButton.TabStop = True
        Me.inputGerRadButton.Text = "German"
        Me.inputGerRadButton.UseVisualStyleBackColor = True
        '
        'inputLabel
        '
        Me.inputLabel.AutoSize = True
        Me.inputLabel.Location = New System.Drawing.Point(12, 9)
        Me.inputLabel.Name = "inputLabel"
        Me.inputLabel.Size = New System.Drawing.Size(90, 15)
        Me.inputLabel.TabIndex = 2
        Me.inputLabel.Text = "Input Language"
        '
        'outputLabel
        '
        Me.outputLabel.AutoSize = True
        Me.outputLabel.Location = New System.Drawing.Point(205, 9)
        Me.outputLabel.Name = "outputLabel"
        Me.outputLabel.Size = New System.Drawing.Size(100, 15)
        Me.outputLabel.TabIndex = 3
        Me.outputLabel.Text = "Output Language"
        '
        'inputTextBox
        '
        Me.inputTextBox.Location = New System.Drawing.Point(12, 171)
        Me.inputTextBox.Name = "inputTextBox"
        Me.inputTextBox.Size = New System.Drawing.Size(100, 23)
        Me.inputTextBox.TabIndex = 4
        '
        'translationLabel
        '
        Me.translationLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.translationLabel.Location = New System.Drawing.Point(205, 171)
        Me.translationLabel.Name = "translationLabel"
        Me.translationLabel.Size = New System.Drawing.Size(100, 23)
        Me.translationLabel.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 153)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 15)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Cardinal Form 1-9:"
        '
        'translateButton
        '
        Me.translateButton.Location = New System.Drawing.Point(121, 171)
        Me.translateButton.Name = "translateButton"
        Me.translateButton.Size = New System.Drawing.Size(75, 23)
        Me.translateButton.TabIndex = 7
        Me.translateButton.Text = "Translate!"
        Me.translateButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 197)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(307, 70)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "*Select your input and output languages. Make sure you enter the number in the co" & _
    "rrect language, using lowercase letters only, then press the translate button."
        '
        'LostInTranslation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(331, 247)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.translateButton)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.translationLabel)
        Me.Controls.Add(Me.inputTextBox)
        Me.Controls.Add(Me.outputLabel)
        Me.Controls.Add(Me.inputLabel)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "LostInTranslation"
        Me.Text = "Lost in Translation"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents outputEngRadButton As System.Windows.Forms.RadioButton
    Friend WithEvents outputFreRadButton As System.Windows.Forms.RadioButton
    Friend WithEvents outputSpaRadButton As System.Windows.Forms.RadioButton
    Friend WithEvents outputGerRadButton As System.Windows.Forms.RadioButton
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents inputEngRadButton As System.Windows.Forms.RadioButton
    Friend WithEvents inputFreRadButton As System.Windows.Forms.RadioButton
    Friend WithEvents inputSpaRadButton As System.Windows.Forms.RadioButton
    Friend WithEvents inputGerRadButton As System.Windows.Forms.RadioButton
    Friend WithEvents inputLabel As System.Windows.Forms.Label
    Friend WithEvents outputLabel As System.Windows.Forms.Label
    Friend WithEvents inputTextBox As System.Windows.Forms.TextBox
    Friend WithEvents translationLabel As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents translateButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
