﻿Public Class LotteryNumberGenerator
    Function genRanNum(min As Integer, max As Integer) As String ' generates a random number in the specified range and returns a string value
        Dim randomNumber As Integer = Int(max * Rnd() + min)
        Return randomNumber
    End Function

    Private Sub playButton_Click(sender As Object, e As EventArgs) Handles playButton.Click
        Dim x As Integer
        For i = 1 To 3
            x = genRanNum(0, 10)
            threeNumTextBox.AppendText(x & " ")

        Next

        For i = 1 To 4
            x = genRanNum(0, 10)
            fourNumTextBox.AppendText(x & " ")

        Next
        For i = 1 To 5
            x = genRanNum(1, 39)
            fiveNumTextBox.AppendText(x & " ")

        Next
        Dim plusOne As Integer
        For i = 1 To 5
            x = genRanNum(1, 49)
            sixNumTextBox.AppendText(x & " ")
            plusOne = genRanNum(1, 42)
            sixNumTextBox.AppendText(plusOne & " ")
        Next
        If threeNumTextBox.Text <> "" Then
            playButton.Enabled = False
            resetButton.Focus()
        End If
    End Sub

    Private Sub resetButton_Click(sender As Object, e As EventArgs) Handles resetButton.Click
        threeNumTextBox.Text = ""
        fourNumTextBox.Text = ""
        fiveNumTextBox.Text = ""
        sixNumTextBox.Text = ""
        playButton.Enabled = True
        playButton.Focus()
    End Sub
End Class
