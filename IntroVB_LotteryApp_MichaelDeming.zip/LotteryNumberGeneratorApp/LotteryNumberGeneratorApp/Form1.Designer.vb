﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LotteryNumberGenerator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.playButton = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.threeNumTextBox = New System.Windows.Forms.TextBox()
        Me.fourNumTextBox = New System.Windows.Forms.TextBox()
        Me.fiveNumTextBox = New System.Windows.Forms.TextBox()
        Me.sixNumTextBox = New System.Windows.Forms.TextBox()
        Me.resetButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'playButton
        '
        Me.playButton.Location = New System.Drawing.Point(15, 151)
        Me.playButton.Name = "playButton"
        Me.playButton.Size = New System.Drawing.Size(131, 23)
        Me.playButton.TabIndex = 1
        Me.playButton.Text = "Good Luck!"
        Me.playButton.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(87, 15)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Three-number:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(149, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 15)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Four-number:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(289, 8)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 15)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Five-number:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(429, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 15)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Five-number +1:"
        '
        'threeNumTextBox
        '
        Me.threeNumTextBox.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.threeNumTextBox.Location = New System.Drawing.Point(15, 27)
        Me.threeNumTextBox.Multiline = True
        Me.threeNumTextBox.Name = "threeNumTextBox"
        Me.threeNumTextBox.ReadOnly = True
        Me.threeNumTextBox.Size = New System.Drawing.Size(100, 111)
        Me.threeNumTextBox.TabIndex = 10
        '
        'fourNumTextBox
        '
        Me.fourNumTextBox.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fourNumTextBox.Location = New System.Drawing.Point(152, 27)
        Me.fourNumTextBox.Multiline = True
        Me.fourNumTextBox.Name = "fourNumTextBox"
        Me.fourNumTextBox.ReadOnly = True
        Me.fourNumTextBox.Size = New System.Drawing.Size(100, 111)
        Me.fourNumTextBox.TabIndex = 11
        '
        'fiveNumTextBox
        '
        Me.fiveNumTextBox.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fiveNumTextBox.Location = New System.Drawing.Point(292, 27)
        Me.fiveNumTextBox.Multiline = True
        Me.fiveNumTextBox.Name = "fiveNumTextBox"
        Me.fiveNumTextBox.ReadOnly = True
        Me.fiveNumTextBox.Size = New System.Drawing.Size(100, 111)
        Me.fiveNumTextBox.TabIndex = 12
        '
        'sixNumTextBox
        '
        Me.sixNumTextBox.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sixNumTextBox.Location = New System.Drawing.Point(432, 27)
        Me.sixNumTextBox.Multiline = True
        Me.sixNumTextBox.Name = "sixNumTextBox"
        Me.sixNumTextBox.ReadOnly = True
        Me.sixNumTextBox.Size = New System.Drawing.Size(100, 111)
        Me.sixNumTextBox.TabIndex = 13
        '
        'resetButton
        '
        Me.resetButton.Location = New System.Drawing.Point(457, 151)
        Me.resetButton.Name = "resetButton"
        Me.resetButton.Size = New System.Drawing.Size(75, 23)
        Me.resetButton.TabIndex = 14
        Me.resetButton.Text = "Try Again"
        Me.resetButton.UseVisualStyleBackColor = True
        '
        'LotteryNumberGenerator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(548, 186)
        Me.Controls.Add(Me.resetButton)
        Me.Controls.Add(Me.sixNumTextBox)
        Me.Controls.Add(Me.fiveNumTextBox)
        Me.Controls.Add(Me.fourNumTextBox)
        Me.Controls.Add(Me.threeNumTextBox)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.playButton)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "LotteryNumberGenerator"
        Me.Text = "Lottery Number Generator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents playButton As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents threeNumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents fourNumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents fiveNumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents sixNumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents resetButton As System.Windows.Forms.Button

End Class
